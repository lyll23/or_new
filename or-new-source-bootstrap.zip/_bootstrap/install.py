"""One-time reviewed source installer. No collection or network downloads."""
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import tempfile
import zipfile

ALLOWED = ('.gitignore', 'config/endpoints.json', 'config/table_mappings.json', 'docs/表格增量说明.md', 'pyproject.toml', 'README.md', 'src/or_pipeline/__init__.py', 'src/or_pipeline/collector.py', 'src/or_pipeline/configuration.py', 'src/or_pipeline/http_capture.py', 'src/or_pipeline/ingest.py', 'src/or_pipeline/native_html.py', 'src/or_pipeline/package.py', 'src/or_pipeline/sync.py', 'tests/test_collector.py', 'tests/test_ingest.py', 'tests/test_native_html.py', 'tests/test_pipeline_e2e.py', 'tests/test_sync.py', 'windows/install-task.ps1', 'windows/sync.ps1')
HELPERS = ('_bootstrap/manifest.json', '_bootstrap/install.py')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def verified_sources(archive_bytes, expected_sha256):
    if sha(archive_bytes) != expected_sha256:
        raise ValueError('Source ZIP SHA256 mismatch')
    with zipfile.ZipFile(io.BytesIO(archive_bytes)) as z:
        infos = z.infolist()
        names = [x.filename for x in infos]
        if len(names) != len(set(names)) or set(names) != set(ALLOWED) | set(HELPERS):
            raise ValueError('ZIP must contain the exact reviewed source and helper set')
        if len({n.casefold() for n in names}) != len(names):
            raise ValueError('Case-folded path collision')
        for info in infos:
            p = PurePosixPath(info.filename)
            if p.is_absolute() or '\\' in info.filename or ':' in info.filename or any(x in ('', '.', '..') for x in info.filename.split('/')):
                raise ValueError('Unsafe archive path')
            if info.is_dir() or stat.S_IFMT(info.external_attr >> 16) != stat.S_IFREG or info.flag_bits & 1:
                raise ValueError('Non-regular or encrypted archive entry')
            if info.file_size > 2_000_000:
                raise ValueError('Not a reviewed small source file')
        manifest = json.loads(z.read(HELPERS[0]))
        records = manifest['files']
        if len(records) != len(ALLOWED) or {x['path'] for x in records} != set(ALLOWED):
            raise ValueError('Source manifest allowlist mismatch')
        result = {}
        for record in records:
            data = z.read(record['path'])  # full read also verifies ZIP CRC
            if len(data) != record['bytes'] or sha(data) != record['sha256']:
                raise ValueError('Source file hash/size mismatch: ' + record['path'])
            result[record['path']] = data
        z.read(HELPERS[1])
        return result

def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args])

def install(archive, expected_sha256, root):
    root = Path(root).resolve()
    source = verified_sources(Path(archive).read_bytes(), expected_sha256)
    if Path(git(root, 'rev-parse', '--show-toplevel').decode().strip()).resolve() != root:
        raise ValueError('Working directory must be the repository root')
    if git(root, 'branch', '--show-current').decode().strip() != 'main':
        raise ValueError('Only the main branch may be bootstrapped')
    if git(root, 'diff', '--cached', '--name-only', '-z'):
        raise ValueError('Refusing a pre-existing staged change')
    # Preflight every target before creating or replacing any file.
    for name in source:
        path = root / name
        for parent in (path, *path.parents):
            if parent == root:
                break
            if parent.is_symlink():
                raise ValueError('Symlink target or parent: ' + name)
        if path.exists() and not path.is_file():
            raise ValueError('Source target is not a regular file: ' + name)
    for name, data in source.items():
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, temp = tempfile.mkstemp(prefix='.source-', dir=path.parent)
        try:
            with os.fdopen(fd, 'wb') as f:
                f.write(data); f.flush(); os.fsync(f.fileno())
            os.chmod(temp, 0o644)
            os.replace(temp, path)
        finally:
            if os.path.exists(temp):
                os.unlink(temp)
    # Explicit filenames only; never git add -A, '.', or an entire directory.
    git(root, '-c', 'core.autocrlf=false', 'add', '--', *ALLOWED)
    staged = {x.decode('utf-8') for x in git(root, 'diff', '--cached', '--name-only', '-z').split(b'\0') if x}
    if not staged.issubset(set(ALLOWED)):
        raise ValueError('Unexpected staged path')
    for name, data in source.items():
        if (root / name).read_bytes() != data or git(root, 'show', ':' + name) != data:
            raise ValueError('Working tree or staged bytes changed: ' + name)
    if not staged:
        print('All reviewed source files are already present; nothing committed.')
        return
    git(root, '-c', 'user.name=github-actions[bot]', '-c', 'user.email=41898282+github-actions[bot]@users.noreply.github.com',
        'commit', '-m', 'Install reviewed OpenRouter source tree')
    git(root, 'push', 'origin', 'HEAD:refs/heads/main')  # no force; concurrent edits fail visibly
    print('Installed and committed ' + str(len(source)) + ' reviewed source files; workflows and ZIP retained unchanged.')

if __name__ == '__main__':
    install(SOURCE_ZIP, SOURCE_SHA256, Path.cwd())
