"""One-time reviewed source installer. No collection or network downloads."""
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import tempfile
import zipfile

ALLOWED = ('.gitignore', 'config/endpoints.json', 'config/table_mappings.json', 'docs/表格增量说明.md', 'pyproject.toml', 'src/or_pipeline/__init__.py', 'src/or_pipeline/collector.py', 'src/or_pipeline/configuration.py', 'src/or_pipeline/http_capture.py', 'src/or_pipeline/ingest.py', 'src/or_pipeline/native_html.py', 'src/or_pipeline/package.py', 'src/or_pipeline/sync.py', 'tests/test_collector.py', 'tests/test_ingest.py', 'tests/test_native_html.py', 'tests/test_pipeline_e2e.py', 'tests/test_sync.py', 'windows/install-task.ps1', 'windows/sync.ps1')
BASELINE_SHA256 = {'.gitignore': '21a3248f62f29769b03e6f33c3888a643dd91333544673f7410c6e4fdd0f4201', 'config/endpoints.json': '1c69e80180866031e0157ee11671b52a110259faea8167ad3b3ec5e987cf9ff2', 'config/table_mappings.json': '603db98043d2444a5e5fabadd03cb0e74141c9699e9dd2c1117abcdefbd41f94', 'docs/表格增量说明.md': 'ac3d442fd2d55ccfec14ed7099e947d477f61d78f9ba25cc0051c5ce49862c5f', 'pyproject.toml': '2a46dc9ab6592aefaff3491106063f994398abfa523f4c5c2cbf9ee1145c9136', 'src/or_pipeline/__init__.py': 'f3e55d18a70707789e68856f12555d805f57b00b3308220ebd4e5ed86005ba8c', 'src/or_pipeline/collector.py': '2ab9239aeb8465edca699a851dd4e267080e3d5ce00d88e0076936d44d90d8c0', 'src/or_pipeline/configuration.py': '8616fe8442c1240f6d444cbe613fa27768aff9ec29bcc3fd7494aabc0b0f381b', 'src/or_pipeline/http_capture.py': 'bb96913b0347bf08d245692592ac469fdaef2e5e54bc588f0fa28132e8fd9fa6', 'src/or_pipeline/ingest.py': '2422abd080735a513590aeca70c0cb8e2a4d931d780ef48e2ef250230b2b39bd', 'src/or_pipeline/native_html.py': 'a8a5069ff09f36ca4e397a6f3ec248781657868b352018dec05ef7a7049d7875', 'src/or_pipeline/package.py': 'd4118421630199d9d2a6471b17e8d46ae425b71ff12f89e554966562b4d0c124', 'src/or_pipeline/sync.py': '7eadc45631f6726f1e3a21de962d746e45617b2c3d6d4bf8837f13ee7c7abafb', 'tests/test_collector.py': '9c739967075c938691a74c5c259e73bb6372e857ed5a04cd3255d3d35082168e', 'tests/test_ingest.py': 'baee46a8a02bcdbb6034762955767cbccd5befdd2bcf847e8c685e8536751900', 'tests/test_native_html.py': '747eaf37a01bd54b6d9a1a80064036c5a72dcb418b5c11beddde3e51e3e923f5', 'tests/test_pipeline_e2e.py': 'a423c519b233547559f23d7b2c732ef7434d01446e5e1b61cd58875d96426dd5', 'tests/test_sync.py': '7fd2ee06e3a984a69a5e653d5029a6b93f81e80620a8d6fa2863b360fb868b6b', 'windows/install-task.ps1': '18e4571052682684d828e53343895642335253bc1b262710876b720cb68c5ce7', 'windows/sync.ps1': '70bb83df08a384591ca8b2dbf3fc58f50c0425d98cab789434cddf192614761b'}
HELPERS = ('_bootstrap/manifest.json', '_bootstrap/install.py')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def verified_sources(archive_bytes, expected_sha256):
    if sha(archive_bytes) != expected_sha256:
        raise ValueError('Source ZIP SHA256 mismatch')
    with zipfile.ZipFile(io.BytesIO(archive_bytes)) as z:
        infos = z.infolist()
        names = [x.filename for x in infos]
        if len(names) != len(set(names)) or set(names) != set(ALLOWED) | set(HELPERS):
            raise ValueError('ZIP must contain the exact reviewed source and helper set')
        if len({n.casefold() for n in names}) != len(names):
            raise ValueError('Case-folded path collision')
        for info in infos:
            p = PurePosixPath(info.filename)
            if p.is_absolute() or '\\' in info.filename or ':' in info.filename or any(x in ('', '.', '..') for x in info.filename.split('/')):
                raise ValueError('Unsafe archive path')
            if info.is_dir() or stat.S_IFMT(info.external_attr >> 16) != stat.S_IFREG or info.flag_bits & 1:
                raise ValueError('Non-regular or encrypted archive entry')
            if info.file_size > 2_000_000:
                raise ValueError('Not a reviewed small source file')
        manifest = json.loads(z.read(HELPERS[0]))
        records = manifest['files']
        if len(records) != len(ALLOWED) or {x['path'] for x in records} != set(ALLOWED):
            raise ValueError('Source manifest allowlist mismatch')
        result = {}
        for record in records:
            data = z.read(record['path'])  # full read also verifies ZIP CRC
            if len(data) != record['bytes'] or sha(data) != record['sha256']:
                raise ValueError('Source file hash/size mismatch: ' + record['path'])
            result[record['path']] = data
        z.read(HELPERS[1])
        return result

def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args])

def check_known_version(name, data, target):
    if name not in ALLOWED or name not in BASELINE_SHA256:
        raise ValueError('Target outside reviewed allowlist')
    if sha(data) not in (BASELINE_SHA256[name], sha(target)):
        raise ValueError('Unknown target content; refusing overwrite: ' + name)

def preflight_targets(root, source):
    if set(source) != set(ALLOWED) or set(BASELINE_SHA256) != set(ALLOWED):
        raise ValueError('Incomplete guarded target set')
    for name, data in source.items():
        path = root / name
        for parent in (path, *path.parents):
            if parent == root:
                break
            if parent.is_symlink():
                raise ValueError('Symlink target or parent: ' + name)
        if not path.is_file():
            raise ValueError('Previously deployed target missing or not regular: ' + name)
        check_known_version(name, path.read_bytes(), data)
        check_known_version(name, git(root, 'show', 'HEAD:' + name), data)

def install(archive, expected_sha256, root):
    root = Path(root).resolve()
    source = verified_sources(Path(archive).read_bytes(), expected_sha256)
    if Path(git(root, 'rev-parse', '--show-toplevel').decode().strip()).resolve() != root:
        raise ValueError('Working directory must be the repository root')
    if git(root, 'branch', '--show-current').decode().strip() != 'main':
        raise ValueError('Only the main branch may be bootstrapped')
    if git(root, 'diff', '--cached', '--name-only', '-z'):
        raise ValueError('Refusing a pre-existing staged change')
    # All guarded files must be deployed v1 or intended v2, before any write.
    # README is absent from every source, target, and staging allowlist.
    head_before = git(root, 'rev-parse', 'HEAD')
    preflight_targets(root, source)
    if git(root, 'rev-parse', 'HEAD') != head_before:
        raise ValueError('HEAD changed during preflight')
    for name, data in source.items():
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, temp = tempfile.mkstemp(prefix='.source-', dir=path.parent)
        try:
            with os.fdopen(fd, 'wb') as f:
                f.write(data); f.flush(); os.fsync(f.fileno())
            os.chmod(temp, 0o644)
            os.replace(temp, path)
        finally:
            if os.path.exists(temp):
                os.unlink(temp)
    if git(root, 'rev-parse', 'HEAD') != head_before:
        raise ValueError('HEAD changed while preparing source files')
    # Explicit filenames only; never git add -A, '.', or an entire directory.
    git(root, '-c', 'core.autocrlf=false', 'add', '--', *ALLOWED)
    staged = {x.decode('utf-8') for x in git(root, 'diff', '--cached', '--name-only', '-z').split(b'\0') if x}
    if not staged.issubset(set(ALLOWED)):
        raise ValueError('Unexpected staged path')
    for name, data in source.items():
        if (root / name).read_bytes() != data or git(root, 'show', ':' + name) != data:
            raise ValueError('Working tree or staged bytes changed: ' + name)
    if not staged:
        print('All reviewed source files are already present; nothing committed.')
        return
    git(root, '-c', 'user.name=github-actions[bot]', '-c', 'user.email=41898282+github-actions[bot]@users.noreply.github.com',
        'commit', '-m', 'Install reviewed OpenRouter source tree')
    git(root, 'push', 'origin', 'HEAD:refs/heads/main')  # no force; concurrent edits fail visibly
    print('Installed and committed ' + str(len(source)) + ' reviewed source files; workflows and ZIP retained unchanged.')

if __name__ == '__main__':
    install(SOURCE_ZIP, SOURCE_SHA256, Path.cwd())
